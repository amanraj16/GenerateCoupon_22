package com.capgemini.capstore.exception;

public class PromocodeDoesNotExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public PromocodeDoesNotExistException(String msg)
	{
		super(msg);
	}

}
