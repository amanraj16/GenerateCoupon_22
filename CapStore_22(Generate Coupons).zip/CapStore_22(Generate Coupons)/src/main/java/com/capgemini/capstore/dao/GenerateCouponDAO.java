package com.capgemini.capstore.dao;





import java.util.List;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.EnableTransactionManagement;


import org.springframework.transaction.annotation.Transactional;

import com.capgemini.capstore.beans.Promo;

@Transactional
@Configuration
@EnableTransactionManagement
@Repository
public interface GenerateCouponDAO extends JpaRepository<Promo, String> {

	@Query(value="SELECT * FROM promo WHERE promo_validity < NOW()", nativeQuery = true)
	public List<Promo> expiredPromocodes();
	
	
	@Modifying(clearAutomatically = true)
	@Query(value="DELETE FROM promo WHERE promo_validity < NOW()", nativeQuery = true)
	public void deleteExpiredPromocodes();
	
	@Modifying(clearAutomatically = true)
	@Query(value="UPDATE promo SET soft_delete ='0' WHERE promo_validity < NOW()",nativeQuery=true)
	public void changeStatus();
	

}
