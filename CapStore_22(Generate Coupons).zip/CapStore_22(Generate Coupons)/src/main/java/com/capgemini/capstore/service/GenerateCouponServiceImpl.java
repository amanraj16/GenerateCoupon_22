package com.capgemini.capstore.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Promo;
import com.capgemini.capstore.dao.GenerateCouponDAO;
import com.capgemini.capstore.exception.PromocodeAlreadyExistException;
import com.capgemini.capstore.exception.PromocodeDoesNotExistException;


@Service
public class GenerateCouponServiceImpl implements GenerateCouponService {

	@Autowired
	GenerateCouponDAO generateCouponDAO;
	
	public GenerateCouponServiceImpl(GenerateCouponDAO generateCouponDAO) {
		super();
		this.generateCouponDAO = generateCouponDAO;
	}
	
	@Override
	public Promo savePromocode(Promo promo) throws PromocodeAlreadyExistException {
		if(generateCouponDAO.existsById(promo.getPromoCode())==false)
			return generateCouponDAO.save(promo);
		else
			throw new PromocodeAlreadyExistException("This Promocode Already Exist");
	}

	

	public Promo findPromocode(String promoCode) throws PromocodeDoesNotExistException {
		if(generateCouponDAO.findById(promoCode).get()!=null)
			return generateCouponDAO.getOne(promoCode);
		else
			throw new PromocodeDoesNotExistException("This Promocode does not exist");
	}
	
	@Override
	public List<Promo> viewActiveCoupons() throws PromocodeDoesNotExistException
	{
		List<Promo> promocodeList = generateCouponDAO.findAll();
		if(!promocodeList.isEmpty())
			return promocodeList;
		else
			throw new PromocodeDoesNotExistException("No Active Promocodes found");
			
	}

	@Override
	public List<Promo> viewExpiredPromos() throws PromocodeDoesNotExistException {
		changeStatusOfExpiredCoupons();
			List<Promo> expiredPromocodesList =  generateCouponDAO.expiredPromocodes();
			
			
			deleteExpiredPromocodes();
			if(!expiredPromocodesList.isEmpty())
			{
				return expiredPromocodesList;
			}
			else
				throw new PromocodeDoesNotExistException("There are no Expired Promocodes");
		}
	
	
	public void changeStatusOfExpiredCoupons() {
		generateCouponDAO.changeStatus();
		
		
	}
	public void deleteExpiredPromocodes()
	{
		generateCouponDAO.deleteExpiredPromocodes();
	}
	
	
}
