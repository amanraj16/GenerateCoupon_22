package com.capgemini.capstore.service;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Promo;
import com.capgemini.capstore.exception.PromocodeAlreadyExistException;
import com.capgemini.capstore.exception.PromocodeDoesNotExistException;

@Service
public interface GenerateCouponService {

	public Promo savePromocode(Promo promo) throws PromocodeAlreadyExistException;
	public Promo findPromocode(String promoCode) throws PromocodeDoesNotExistException;
	public List<Promo> viewActiveCoupons() throws PromocodeDoesNotExistException;
	public List<Promo> viewExpiredPromos() throws PromocodeDoesNotExistException;
	public void changeStatusOfExpiredCoupons();
}
