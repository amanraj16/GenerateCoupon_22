package com.capgemini.capstore.exception;

public class PromocodeAlreadyExistException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PromocodeAlreadyExistException(String msg)
	{
		super(msg);
	}
}
