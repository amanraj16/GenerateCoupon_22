package com.capgemini.capstore.controller;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Promo;

import com.capgemini.capstore.exception.PromocodeAlreadyExistException;
import com.capgemini.capstore.exception.PromocodeDoesNotExistException;
import com.capgemini.capstore.service.GenerateCouponService;

@RestController
public class GenerateCouponController {

	@Autowired
	GenerateCouponService generateCouponService;
	
	@RequestMapping(value="/createPromocode",method=RequestMethod.POST)
	public Promo createPromocode(@Valid @RequestBody Promo promo) throws PromocodeAlreadyExistException
	{
		
		return generateCouponService.savePromocode(promo);
	}
	
	@RequestMapping(value="/findPromocode/{promoCode}",method=RequestMethod.GET)
	public Promo findPromocode(@Valid @PathVariable String promoCode) throws PromocodeDoesNotExistException
	{
		
		return generateCouponService.findPromocode(promoCode);
	}
	
	@RequestMapping(value="/viewActivePromocodes",method=RequestMethod.GET)
	public List<Promo> viewActivePromocodes() throws PromocodeAlreadyExistException, PromocodeDoesNotExistException
	{
		return generateCouponService.viewActiveCoupons();
	}
	@RequestMapping(value="/viewExpiredPromocodes",method=RequestMethod.GET)
	public List<Promo> viewExpiredPromocodes() throws PromocodeDoesNotExistException
	{
		List<Promo> expiredPromocodes =  generateCouponService.viewExpiredPromos();
		
		return expiredPromocodes;
	}
}
